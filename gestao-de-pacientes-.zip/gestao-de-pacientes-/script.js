"use strict";

// Login demonstrativo: a senha e os dados podem ser inspecionados no navegador.
const CHAVE = "clinicaViva.v3";
const $ = id => document.getElementById(id);
const vazio = () => ({ versao: 3, pacientes: [], consultas: [] });
const esc = valor => String(valor ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[c]);
const dataLocal = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const hoje = () => dataLocal(new Date());
const dataBR = iso => iso.split("-").reverse().join("/");
const novaId = () => globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
let banco = vazio(), autenticado = false, bloqueado = false, timerToast;
let diaSelecionado = hoje(), mesCalendario = new Date(`${diaSelecionado.slice(0,7)}-01T12:00:00`);

function avisar(mensagem, erro = false) {
  const el = $("toast");
  (document.querySelector("dialog[open]") || document.body).append(el);
  el.textContent = mensagem; el.classList.toggle("error", erro); el.hidden = false;
  clearTimeout(timerToast); timerToast = setTimeout(() => { el.hidden = true; }, 6000);
}
function avisoBanco(mensagem = "") {
  bloqueado = Boolean(mensagem); $("avisoBanco").textContent = mensagem; $("avisoBanco").hidden = !mensagem;
}
function dataValida(iso) {
  return /^\d{4}-\d{2}-\d{2}$/.test(iso) && Number(iso.slice(0,4)) >= 1900 && dataLocal(new Date(`${iso}T12:00:00`)) === iso;
}
function proximaVisita(p) {
  const [ano, mes, dia] = p.ultimaVisita.split("-").map(Number);
  const d = new Date(ano, mes - 1 + p.periodicidade, 1, 12);
  d.setDate(Math.min(dia, new Date(d.getFullYear(), d.getMonth()+1, 0).getDate()));
  return dataLocal(d);
}
function statusVisita(p) {
  const dias = (Date.parse(`${proximaVisita(p)}T00:00:00Z`) - Date.parse(`${hoje()}T00:00:00Z`)) / 86400000;
  return dias < 0 ? "atrasado" : dias <= 30 ? "proximo" : "dia";
}

// Valida a base inteira antes de gravar. Também aceita o array do backup antigo.
function validarBase(entrada) {
  const base = Array.isArray(entrada) ? { ...vazio(), pacientes:entrada } : entrada;
  const exigir = (condicao, mensagem) => { if (!condicao) throw new Error(mensagem); };
  exigir(base && [2,3].includes(base.versao), "Formato ou versão do backup inválidos.");
  for (const nome of ["pacientes","consultas"]) exigir(Array.isArray(base[nome]), `Lista de ${nome} inválida.`);
  const texto = (obj, campo, max = 5000, obrigatorio = false) => {
    exigir(obj && typeof obj === "object" && !Array.isArray(obj), "Registro inválido.");
    const valor = obj[campo] ?? "";
    exigir(typeof valor === "string" && valor.length <= max, `Campo ${campo} inválido.`);
    exigir(!obrigatorio || valor.trim(), `Preencha ${campo}.`);
    return valor.trim();
  };
  const id = obj => {
    exigir(obj && ["string","number"].includes(typeof obj.id), "Identificador inválido.");
    return texto({ id:String(obj.id) }, "id", 128, true);
  };
  const data = (obj, campo) => { const v = texto(obj,campo,10,true); exigir(dataValida(v), `Data inválida: ${campo}.`); return v; };
  const pacientes = base.pacientes.map(p => {
    const periodicidade = Number(p?.periodicidade);
    exigir([6,12].includes(periodicidade), "Periodicidade inválida.");
    return { id:id(p), nome:texto(p,"nome",160,true), telefone:texto(p,"telefone",30), ultimaVisita:data(p,"ultimaVisita"), periodicidade,
      historicoMedico:texto(p,"historicoMedico"), medicacoes:texto(p,"medicacoes"), alergias:texto(p,"alergias",2000), observacoes:texto(p,"observacoes"), dataCadastro:texto(p,"dataCadastro",40) };
  });
  const ids = new Set(pacientes.map(p => p.id));
  const vinculo = obj => { const v = texto(obj,"pacienteId",128,true); exigir(ids.has(v), "Paciente vinculado não encontrado."); return v; };
  const consultas = base.consultas.map(c => {
    const hora = texto(c,"hora",5,true), status = texto(c,"status",20,true);
    exigir(/^([01]\d|2[0-3]):[0-5]\d$/.test(hora), "Horário inválido.");
    exigir(["agendada","realizada","cancelada"].includes(status), "Status de consulta inválido.");
    return { id:id(c), pacienteId:vinculo(c), data:data(c,"data"), hora, status, motivo:texto(c,"motivo",180,true) };
  });
  for (const lista of [pacientes,consultas]) exigir(new Set(lista.map(x => x.id)).size === lista.length, "Há identificadores duplicados.");
  const horarios = consultas.filter(c => c.status !== "cancelada").map(c => `${c.data} ${c.hora}`);
  exigir(new Set(horarios).size === horarios.length, "Há consultas no mesmo horário.");
  return { versao:3, pacientes, consultas };
}

// Lê a base original uma única vez; não apaga nem altera o IndexedDB antigo.
function lerPacientesAntigos() {
  return new Promise((resolve,reject) => {
    if (!globalThis.indexedDB) { resolve([]); return; }
    let conexao, terminou = false;
    const finalizar = (erro, lista = []) => {
      if (terminou) return;
      terminou = true; clearTimeout(limite); conexao?.close(); erro ? reject(erro) : resolve(lista);
    };
    const limite = setTimeout(() => finalizar(new Error("Feche as outras abas do sistema e entre novamente.")), 7000);
    const r = indexedDB.open("GestaoPacientesDB");
    r.onupgradeneeded = () => { r.transaction.abort(); finalizar(null); };
    r.onerror = () => finalizar(r.error);
    r.onblocked = () => finalizar(new Error("A base antiga está bloqueada em outra aba."));
    r.onsuccess = () => {
      conexao = r.result;
      if (terminou) { conexao.close(); return; }
      if (!conexao.objectStoreNames.contains("pacientes")) { finalizar(null); return; }
      const tx = conexao.transaction("pacientes","readonly"), req = tx.objectStore("pacientes").getAll();
      tx.oncomplete = () => finalizar(null,req.result);
      tx.onabort = () => finalizar(tx.error || new Error("Falha ao ler os pacientes antigos."));
    };
  });
}
async function carregarBanco() {
  try {
    const salvo = localStorage.getItem(CHAVE);
    if (salvo !== null) banco = validarBase(JSON.parse(salvo));
    else {
      const anterior = localStorage.getItem("gestaoPacientes.v2");
      banco = validarBase(anterior === null ? await lerPacientesAntigos() : JSON.parse(anterior));
      localStorage.setItem(CHAVE,JSON.stringify(banco));
      if (banco.pacientes.length) avisar(`${banco.pacientes.length} pacientes migrados para localStorage.`);
    }
    avisoBanco();
  } catch (erro) {
    banco = vazio();
    avisoBanco(`Não foi possível carregar a base: ${erro.message} Os dados existentes não serão sobrescritos. Restaure um backup válido ou tente entrar novamente.`);
  }
}
function salvarBase(proximo, restauracao = false) {
  if (!autenticado) return false;
  try {
    if (bloqueado && !restauracao) throw new Error("Restaure um backup válido antes de alterar a base.");
    const validado = validarBase(proximo);
    localStorage.setItem(CHAVE,JSON.stringify(validado));
    banco = validado; avisoBanco(); renderizar(); return true;
  } catch (erro) { avisar(`Não foi possível salvar. ${erro.message}`,true); return false; }
}

function renderizar() {
  const paciente = id => banco.pacientes.find(p => p.id === id);
  $("totalPacientes").textContent = banco.pacientes.length;
  $("totalConsultas").textContent = banco.consultas.filter(c => c.data === hoje() && c.status !== "cancelada").length;
  $("totalProximos").textContent = banco.pacientes.filter(p => statusVisita(p) === "proximo").length;
  $("totalAlergias").textContent = banco.pacientes.filter(p => p.alergias).length;
  const ordenados = [...banco.pacientes].sort((a,b) => a.nome.localeCompare(b.nome,"pt-BR"));
  const seletor = $("consultaPaciente"), valorAtual = seletor.value;
  seletor.innerHTML = '<option value="">Selecione um paciente</option>' + ordenados.map(p => `<option value="${esc(p.id)}">${esc(p.nome)}</option>`).join("");
  seletor.value = valorAtual;
  const simplificar = s => s.toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g,"");
  const busca = simplificar($("busca").value.trim()), digitos = busca.replace(/\D/g,"");
  const filtrados = ordenados.filter(p => (simplificar(p.nome).includes(busca) || (digitos && p.telefone.replace(/\D/g,"").includes(digitos))) && ($("filtro").value === "todos" || statusVisita(p) === $("filtro").value));
  $("contadorPacientes").textContent = `${filtrados.length} de ${banco.pacientes.length} paciente(s)`;
  const rotulos = { dia:"Em dia", proximo:"Retorno próximo", atrasado:"Retorno atrasado" };
  const botao = (acao,id,texto,classe="") => `<button type="button" class="${classe}" data-acao="${acao}" data-id="${esc(id)}">${texto}</button>`;
  $("listaPacientes").innerHTML = filtrados.map(p => {
    const status=statusVisita(p), inicial=Array.from(p.nome)[0] || "?";
    return `<article class="patient-card">
      <div class="patient-heading"><span class="avatar" aria-hidden="true">${esc(inicial)}</span><div><h3>${esc(p.nome)}</h3><p class="patient-phone">${esc(p.telefone)||"Telefone não informado"}</p></div></div>
      <span class="badge ${status==="dia"?"ok":status}">${rotulos[status]}</span>
      ${p.alergias?`<p class="allergy-tag">⚠ Alergias: ${esc(p.alergias.slice(0,140))}${p.alergias.length>140?"…":""}</p>`:'<p class="small muted spaced">Alergias não informadas.</p>'}
      <dl class="patient-dates"><div><dt>Última visita</dt><dd>${dataBR(p.ultimaVisita)}</dd></div><div><dt>Próximo retorno</dt><dd>${dataBR(proximaVisita(p))}</dd></div></dl>
      <div class="actions">${botao("ver",p.id,"Prontuário","secondary")}${botao("editar",p.id,"Editar")}${botao("excluirPaciente",p.id,"Excluir","danger")}</div>
    </article>`;
  }).join("") || '<div class="empty"><strong>Um espaço para novas histórias</strong><p>Nenhum paciente encontrado. Cadastre um paciente ou ajuste a busca.</p></div>';
  const consultas = banco.consultas.filter(c => c.data === diaSelecionado).sort((a,b) => a.hora.localeCompare(b.hora));
  $("rotuloDia").textContent = `${dataBR(diaSelecionado)} · ${consultas.length} consulta(s)`;
  $("listaConsultas").innerHTML = consultas.map(c => {
    const p=paciente(c.pacienteId);
    return `<article class="appointment"><time datetime="${c.data}T${c.hora}">${c.hora}</time><div class="appointment-info"><strong>${esc(p.nome)}</strong><p class="muted">${esc(c.motivo)}</p><span class="badge ${c.status==="realizada"?"ok":c.status==="cancelada"?"atrasado":"proximo"}">${{agendada:"Agendada",realizada:"Realizada",cancelada:"Cancelada"}[c.status]}</span>${p.alergias?`<p class="allergy-tag">⚠ Alergias: ${esc(p.alergias)}</p>`:""}<div class="actions">${c.status==="agendada"?botao("realizar",c.id,"Concluir")+botao("cancelar",c.id,"Cancelar"):""}${botao("excluirConsulta",c.id,"Excluir","danger")}</div></div></article>`;
  }).join("") || '<div class="empty"><strong>Um respiro na agenda ✦</strong><p>Nenhuma consulta neste dia.</p></div>';
  renderizarCalendario();
}
function renderizarCalendario() {
  $("tituloMes").textContent = mesCalendario.toLocaleDateString("pt-BR",{month:"long",year:"numeric"});
  const ano=mesCalendario.getFullYear(), mes=mesCalendario.getMonth(), dias=new Date(ano,mes+1,0).getDate();
  let html = '<span aria-hidden="true"></span>'.repeat(new Date(ano,mes,1).getDay());
  const contagens = new Map();
  banco.consultas.filter(c => c.status!=="cancelada").forEach(c => contagens.set(c.data,(contagens.get(c.data)||0)+1));
  for (let dia=1;dia<=dias;dia++) {
    const iso=dataLocal(new Date(ano,mes,dia,12)), n=contagens.get(iso)||0;
    html += `<button type="button" data-dia="${iso}" aria-pressed="${iso===diaSelecionado}" aria-label="${dataBR(iso)}, ${n} consulta(s)" ${iso===hoje()?'aria-current="date"':""} class="${iso===diaSelecionado?"selected ":""}${iso===hoje()?"today ":""}${n?"has-event":""}">${dia}</button>`;
  }
  $("calendario").innerHTML=html; $("diaAgenda").value=diaSelecionado;
}
function selecionarDia(iso) {
  if (!dataValida(iso)) return;
  diaSelecionado=iso; mesCalendario=new Date(`${iso.slice(0,7)}-01T12:00:00`);
  $("consultaData").value=iso; renderizar();
}
function abrirPaciente(id = "") {
  const p=banco.pacientes.find(x => x.id===id);
  $("formPaciente").reset(); $("pacienteId").value=id; $("tituloPaciente").textContent=p?"Editar paciente":"Novo paciente";
  for (const campo of ["nome","telefone","ultimaVisita","periodicidade","historicoMedico","medicacoes","alergias","observacoes"]) if(p) $(campo).value=p[campo];
  if(!p) $("ultimaVisita").value=hoje();
  $("ultimaVisita").max=hoje(); atualizarAlergia(); $("modalPaciente").showModal();
}
function atualizarAlergia() {
  const valor=$("alergias").value.trim(); $("alertaAlergia").hidden=!valor; $("alertaAlergia").textContent=`⚠ Atenção às alergias registradas: ${valor}`;
}
function verPaciente(p) {
  $("tituloFicha").textContent=p.nome;
  const campos={Telefone:p.telefone,"Data de cadastro":dataValida(p.dataCadastro.slice(0,10))?dataBR(p.dataCadastro.slice(0,10)):"","Última visita":dataBR(p.ultimaVisita),"Próximo retorno":dataBR(proximaVisita(p)),"Histórico médico":p.historicoMedico,"Medicações de uso contínuo":p.medicacoes,"Observações médicas":p.observacoes};
  $("conteudoFicha").innerHTML=(p.alergias?`<p class="alerta">⚠ Alergias: ${esc(p.alergias)}</p>`:'<p class="muted">Alergias não informadas.</p>')+Object.entries(campos).map(([nome,valor])=>`<section><h3>${nome}</h3><p>${esc(valor)||"Não informado"}</p></section>`).join("");
  $("modalFicha").showModal();
}

$("formLogin").addEventListener("submit",async e => {
  e.preventDefault();
  if($("senha").value!=="Rosilene123") { $("loginErro").textContent="Senha incorreta. Tente novamente."; $("senha").focus(); return; }
  const btn=$("entrar"); btn.disabled=true; btn.textContent="Carregando…";
  await carregarBanco(); autenticado=true; renderizar();
  $("login").hidden=true; $("painel").hidden=false; $("senha").value=""; $("loginErro").textContent="";
  $("dataHoje").textContent=new Date().toLocaleDateString("pt-BR",{day:"numeric",month:"long",year:"numeric"});
  $("consultaData").value=diaSelecionado; mostrarAba("pacientes");
  document.querySelector("[data-aba]").focus(); btn.disabled=false; btn.textContent="Entrar no painel →";
});
$("sair").addEventListener("click",() => {
  document.querySelectorAll("dialog[open]").forEach(d=>d.close()); autenticado=false; banco=vazio(); renderizar();
  $("formPaciente").reset(); $("formConsulta").reset(); $("conteudoFicha").textContent="";
  $("painel").hidden=true; $("login").hidden=false; $("toast").hidden=true; $("senha").focus();
});
function mostrarAba(nome) {
  document.querySelectorAll("[data-aba]").forEach(btn => {
    const ativa=btn.dataset.aba===nome;
    btn.setAttribute("aria-pressed",String(ativa)); $(btn.dataset.aba).hidden=!ativa;
  });
}
document.querySelectorAll("[data-aba]").forEach(btn => btn.addEventListener("click",()=>mostrarAba(btn.dataset.aba)));
$("novoPaciente").addEventListener("click",()=>abrirPaciente());
$("alergias").addEventListener("input",atualizarAlergia);
$("busca").addEventListener("input",renderizar); $("filtro").addEventListener("change",renderizar);
$("diaAgenda").addEventListener("change",e=>selecionarDia(e.target.value)); $("irHoje").addEventListener("click",()=>selecionarDia(hoje()));
for (const [id,passo] of [["mesAnterior",-1],["mesSeguinte",1]]) $(id).addEventListener("click",()=>{
  const d=new Date(mesCalendario.getFullYear(),mesCalendario.getMonth()+passo,1,12);
  if(d.getFullYear()>=1900 && d.getFullYear()<=9999) { mesCalendario=d; renderizarCalendario(); }
});
$("formPaciente").addEventListener("submit",e => {
  e.preventDefault(); const id=$("pacienteId").value, anterior=banco.pacientes.find(p=>p.id===id);
  const p={id:id||novaId(),dataCadastro:anterior?.dataCadastro||new Date().toISOString()};
  for(const campo of ["nome","telefone","ultimaVisita","historicoMedico","medicacoes","alergias","observacoes"]) p[campo]=$(campo).value.trim();
  p.periodicidade=Number($("periodicidade").value);
  const pacientes=anterior?banco.pacientes.map(x=>x.id===id?p:x):[...banco.pacientes,p];
  if(salvarBase({...banco,pacientes})) { $("modalPaciente").close(); avisar("Paciente salvo com sucesso."); }
});
$("formConsulta").addEventListener("submit",e => {
  e.preventDefault();
  const c={id:novaId(),pacienteId:$("consultaPaciente").value,data:$("consultaData").value,hora:$("consultaHora").value,motivo:$("consultaMotivo").value.trim(),status:"agendada"};
  if(salvarBase({...banco,consultas:[...banco.consultas,c]})) { e.target.reset(); selecionarDia(c.data); avisar("Consulta agendada."); }
});
document.addEventListener("click",e => {
  const btn=e.target.closest?.("button"); if(!btn) return;
  if(btn.dataset.fechar) $(btn.dataset.fechar).close();
  if(!autenticado) return;
  if(btn.dataset.dia) { selecionarDia(btn.dataset.dia); document.querySelector(`[data-dia="${btn.dataset.dia}"]`)?.focus(); }
  const {acao,id}=btn.dataset, p=banco.pacientes.find(x=>x.id===id);
  if(acao==="ver" && p) verPaciente(p);
  if(acao==="editar" && p) abrirPaciente(id);
  if(acao==="excluirPaciente" && p) {
    if(banco.consultas.some(c=>c.pacienteId===id)) { avisar("Exclua primeiro as consultas vinculadas a este paciente.",true); return; }
    if(confirm(`Excluir o paciente ${p.nome}? Esta ação não pode ser desfeita.`) && salvarBase({...banco,pacientes:banco.pacientes.filter(x=>x.id!==id)})) avisar("Paciente excluído.");
  }
  if(acao==="realizar"||acao==="cancelar") {
    if(acao==="cancelar" && !confirm("Cancelar esta consulta?")) return;
    if(salvarBase({...banco,consultas:banco.consultas.map(c=>c.id===id?{...c,status:acao==="realizar"?"realizada":"cancelada"}:c)})) avisar("Consulta atualizada.");
  }
  if(acao==="excluirConsulta" && confirm("Excluir esta consulta permanentemente?") && salvarBase({...banco,consultas:banco.consultas.filter(x=>x.id!==id)})) avisar("Consulta excluída.");
});

$("exportar").addEventListener("click",() => {
  if(!autenticado || bloqueado) { avisar("A base não foi carregada. Não é possível exportar.",true); return; }
  const url=URL.createObjectURL(new Blob([JSON.stringify(banco,null,2)],{type:"application/json"}));
  const a=document.createElement("a"); a.href=url; a.download=`backup-viva-${hoje()}.json`; document.body.append(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000); avisar("Backup exportado.");
});
$("importar").addEventListener("click",()=>$("arquivoBackup").click());
$("arquivoBackup").addEventListener("change",async e => {
  const arquivo=e.target.files[0]; if(!arquivo) return;
  try {
    if(arquivo.size>5*1024*1024) throw new Error("O limite por arquivo é 5 MB.");
    const importado=validarBase(JSON.parse(await arquivo.text()));
    if(!autenticado) return;
    const resumo=`${importado.pacientes.length} pacientes e ${importado.consultas.length} consultas`;
    if(confirm(`Restaurar ${resumo}? A base atual será substituída. Exporte um backup antes de continuar.`) && salvarBase(importado,true)) avisar("Backup restaurado.");
  } catch(erro) { avisar(`Backup inválido. ${erro.message}`,true); }
  finally { e.target.value=""; }
});
window.addEventListener("storage",e => {
  if((e.key!==CHAVE && e.key!==null) || !autenticado) return;
  try { banco=e.newValue===null?vazio():validarBase(JSON.parse(e.newValue)); avisoBanco(); renderizar(); avisar("Dados atualizados por outra aba."); }
  catch { avisoBanco("A base foi alterada em outra aba e ficou inválida. Restaure um backup válido."); }
});
